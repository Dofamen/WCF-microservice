﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Demo2
{
    public class DemoRepository
    {
        public static readonly List<User> _users = new List<User>
        {
            new User
            {
                id = 1,
                FullName = "test",
                birthday = new DateTime(),
                IsAdult = true,
                Gender = Gender.Male,
                Adesses = new List<Adresse>
                {
                    new Adresse
                    {

                        Ville = "Casablanca",
                        Quartier = "DS"
                    },
                    new Adresse
                    {
                        Ville = "Casablanca",
                        Quartier = "DS"
                    }
                }
            }
        };

    }

    [DataContract]
    public class User
    {
        [Key]
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string FullName { get; set; }

        public DateTime? birthday;

        [DataMember]
        public string BirthDate { get => this.birthday.ToString(); set => this.birthday = Convert.ToDateTime(value); }

        [DataMember]
        public Boolean IsAdult { get; set; }
        [DataMember]
        public Gender Gender { get; set; }
        [DataMember]
        public List<Adresse> Adesses { get; set; }

        public void Copy(User user)
        {
            this.id = user.id;
            this.FullName = user.FullName;
            this.BirthDate = user.BirthDate;
            this.IsAdult = user.IsAdult;
            this.Gender = user.Gender;
            this.Adesses = user.Adesses;
        }

    }

    [DataContract]
    public class Adresse
    {
        [Key]
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string Ville { get; set; }
        [DataMember]
        public string Quartier { get; set; }
    }

    public enum Gender
    {
        Male,
        Female
    }
}