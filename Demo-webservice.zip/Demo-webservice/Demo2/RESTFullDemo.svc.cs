﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Demo2
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "RESTFullDemo" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select RESTFullDemo.svc or RESTFullDemo.svc.cs at the Solution Explorer and start debugging.
    public class RESTFullDemo : IRESTFullDemo
    {
        public bool Delete(int id)
        {
            return UserService.DeleteUser(id);
        }


        public User GetUser(int id)
        {
            return UserService.getUser(id);
        }

        public List<User> GetUsers()
        {
            return UserService.GetAll();
        }

        public User Post(User user)
        {
            return UserService.AddUser(user);
        }

        public User Put(User user)
        {
            return UserService.UpdateUser(user);
        }
    }
}
