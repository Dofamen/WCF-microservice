﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Demo2
{
    public class UserService
    {
        private static DBEFContext context = new DBEFContext();

        public static User AddUser(User user)
        {
            try
            {
                DemoRepository._users.Add(user);

                var user2 = context.Users.Add(user);
                context.SaveChanges();

                return user2;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public static User UpdateUser(User user)
        {
            try
            {
                //var target = DemoRepository._users.Where(_ => _.id == user.id).FirstOrDefault();

                var target = (from _ in context.Users where _.id == user.id select _).FirstOrDefault();

                if (target is null)
                {
                    return null;
                }

                target.Copy(user);
                context.SaveChanges();

                return target;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static List<User> GetAll()
        {
            return context.Users.ToList();
        }

        public static User getUser(int id)
        {
            return context.Users.Where(_ => _.id == id).FirstOrDefault();

        }

        public static Boolean DeleteUser(int id)
        {
            var target = context.Users.Where(_ => _.id == id).FirstOrDefault();

            if (target is null) throw new ArgumentNullException(nameof(target));

            return context.Users.Remove(target) != null;
        }
    }
}