﻿using System.Data.Entity;


namespace Demo2
{
    public class DBEFContext : DbContext
    {
        public DBEFContext() : base("connectionPath")
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Adresse> Adresses { get; set; }
    }
}